package edu.jjc.week3.lab02;
//Oscar Alcantar - Car class file
public class Car {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
