package edu.jjc.week12.lab12;

public class Fish  extends Animal{
    public Fish(String name){
        super(name);
    }

    public void eat(){
        System.out.println("Fish eat");
    }
}
