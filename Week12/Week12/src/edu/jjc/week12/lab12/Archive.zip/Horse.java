package edu.jjc.week12.lab12;

public class Horse  extends Animal{
    public Horse(String name){
        super(name);
    }

}
