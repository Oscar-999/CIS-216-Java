package edu.jjc.week12.homework12;

public abstract class Shape {
    public abstract double calculateArea();
    // Abstract since method is not defined fully
    public abstract String toString();

}
